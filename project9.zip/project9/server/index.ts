import express from 'express';
import cors from 'cors';
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3001;

// Create chats directory if it doesn't exist
const CHATS_DIR = path.join(__dirname, 'chats');
await fs.mkdir(CHATS_DIR, { recursive: true });

app.use(cors());
app.use(express.json());

// List all chats
app.get('/api/chats', async (req, res) => {
  try {
    const files = await fs.readdir(CHATS_DIR);
    const chats = await Promise.all(
      files.map(async (file) => {
        const content = await fs.readFile(path.join(CHATS_DIR, file), 'utf-8');
        return JSON.parse(content);
      })
    );
    res.json(chats.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()));
  } catch (error) {
    console.error('Error listing chats:', error);
    res.status(500).json({ error: 'Failed to list chats' });
  }
});

// Get a specific chat
app.get('/api/chats/:id', async (req, res) => {
  try {
    const chatPath = path.join(CHATS_DIR, `${req.params.id}.json`);
    const content = await fs.readFile(chatPath, 'utf-8');
    res.json(JSON.parse(content));
  } catch (error) {
    console.error('Error reading chat:', error);
    res.status(404).json({ error: 'Chat not found' });
  }
});

// Save or update a chat
app.post('/api/chats', async (req, res) => {
  try {
    const chat = req.body;
    const chatPath = path.join(CHATS_DIR, `${chat.id}.json`);
    await fs.writeFile(chatPath, JSON.stringify(chat, null, 2));
    res.json(chat);
  } catch (error) {
    console.error('Error saving chat:', error);
    res.status(500).json({ error: 'Failed to save chat' });
  }
});

// Update chat title
app.patch('/api/chats/:id/title', async (req, res) => {
  try {
    const chatPath = path.join(CHATS_DIR, `${req.params.id}.json`);
    const content = await fs.readFile(chatPath, 'utf-8');
    const chat = JSON.parse(content);
    chat.title = req.body.title;
    chat.updatedAt = new Date().toISOString();
    await fs.writeFile(chatPath, JSON.stringify(chat, null, 2));
    res.json(chat);
  } catch (error) {
    console.error('Error updating chat title:', error);
    res.status(500).json({ error: 'Failed to update chat title' });
  }
});

// Delete a chat
app.delete('/api/chats/:id', async (req, res) => {
  try {
    const chatPath = path.join(CHATS_DIR, `${req.params.id}.json`);
    await fs.unlink(chatPath);
    res.status(204).send();
  } catch (error) {
    console.error('Error deleting chat:', error);
    res.status(500).json({ error: 'Failed to delete chat' });
  }
});

app.listen(PORT, () => {
  console.log(`Chat storage server running on port ${PORT}`);
});