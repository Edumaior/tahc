import React from 'react';
import { ChatHeader } from './components/ChatHeader';
import { ChatWindow } from './components/ChatWindow';
import { ChatInput } from './components/ChatInput';
import { ChatList } from './components/ChatList';
import { PersonaSelector } from './components/PersonaSelector';
import { useChat } from './hooks/useChat';

function App() {
  const { 
    messages, 
    isLoading, 
    error, 
    settings,
    savedChats,
    currentChatId,
    selectedPersona,
    sendMessage, 
    regenerateLastMessage,
    handleFeedback,
    updateSettings,
    clearChat,
    startNewChat,
    loadChat,
    deleteChat,
    updateChatTitle,
    selectPersona
  } = useChat();

  return (
    <div className="flex h-screen bg-gray-50">
      <ChatList
        chats={savedChats}
        onSelectChat={(chat) => loadChat(chat.id)}
        onDeleteChat={deleteChat}
        onUpdateChatTitle={updateChatTitle}
        selectedChatId={currentChatId || undefined}
      />
      <div className="flex flex-col flex-1">
        <ChatHeader 
          onClearChat={clearChat}
          onNewChat={startNewChat}
          settings={settings}
          onSettingsChange={updateSettings}
        />
        {messages.length === 0 && (
          <PersonaSelector
            selectedPersonaId={selectedPersona?.id}
            onSelectPersona={selectPersona}
          />
        )}
        <ChatWindow 
          messages={messages} 
          isLoading={isLoading} 
          error={error}
          onRegenerate={regenerateLastMessage}
          onFeedback={handleFeedback}
        />
        <footer className="max-w-3xl mx-auto w-full">
          <ChatInput onSendMessage={sendMessage} disabled={isLoading} />
        </footer>
      </div>
    </div>
  );
}

export default App;