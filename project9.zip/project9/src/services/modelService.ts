import Groq from 'groq-sdk';
import { ChatSettings } from '../types/chat';

export async function getAvailableModels(apiKey: string) {
  if (!apiKey) {
    throw new Error('API key is required to fetch available models');
  }

  try {
    const groq = new Groq({ apiKey });
    const models = await groq.models.list();
    return models.data.map(model => ({
      id: model.id,
      name: model.id,
      contextWindow: model.context_window,
      owner: model.owned_by
    }));
  } catch (error: any) {
    console.error('Error fetching models:', error);
    throw new Error('Failed to fetch available models. Please check your API key.');
  }
}