import axios from 'axios';

const GROK_API_URL = 'https://api.grok.ai/v1/chat/completions';
const API_KEY = import.meta.env.VITE_GROK_API_KEY;

export async function sendMessageToGrok(message: string): Promise<string> {
  if (!API_KEY) {
    throw new Error('Grok API key is not configured. Please add VITE_GROK_API_KEY to your environment variables.');
  }

  try {
    const response = await axios.post(
      GROK_API_URL,
      {
        messages: [{ role: 'user', content: message }],
        model: 'grok-1',
      },
      {
        headers: {
          'Authorization': `Bearer ${API_KEY}`,
          'Content-Type': 'application/json',
        },
      }
    );

    return response.data.choices[0].message.content;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      if (error.response?.status === 401) {
        throw new Error('Invalid API key. Please check your Grok API key configuration.');
      }
      throw new Error(`API Error: ${error.response?.data?.error?.message || 'Unknown error occurred'}`);
    }
    throw error;
  }
}