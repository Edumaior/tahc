import axios from 'axios';
import { Message, ChatSettings } from '../types/chat';
import { GroqError } from '../types/errors';

const GROQ_API_URL = 'https://api.groq.com/openai/v1';

export async function sendMessageToGroq(
  messages: Message[],
  settings: ChatSettings
): Promise<string> {
  if (!settings.apiKey) {
    throw new GroqError('API_KEY_MISSING', 'Please configure your Groq API key in the settings.');
  }

  try {
    const response = await axios.post(
      `${GROQ_API_URL}/chat/completions`,
      {
        messages: messages.map(({ role, content }) => ({ role, content })),
        model: settings.model,
        temperature: settings.temperature,
        top_p: settings.topP,
        max_tokens: settings.maxTokens,
        presence_penalty: settings.presencePenalty,
        frequency_penalty: settings.frequencyPenalty,
        stop: settings.stop.length > 0 ? settings.stop : undefined,
      },
      {
        headers: {
          'Authorization': `Bearer ${settings.apiKey}`,
          'Content-Type': 'application/json',
        },
      }
    );

    if (!response.data.choices?.[0]?.message?.content) {
      throw new GroqError('NO_RESPONSE', 'No response received from Groq');
    }

    return response.data.choices[0].message.content;
  } catch (error: any) {
    if (axios.isAxiosError(error)) {
      if (error.response?.status === 401) {
        throw new GroqError('INVALID_API_KEY', 'Invalid API key. Please check your Groq API key in the settings.');
      }
      if (error.response?.status === 429) {
        throw new GroqError('RATE_LIMIT', 'Rate limit exceeded. Please try again later.');
      }
      if (error.response?.status === 500) {
        throw new GroqError('SERVER_ERROR', 'Groq server error. Please try again later.');
      }
      
      console.error('Groq API Error:', {
        status: error.response?.status,
        message: error.message,
        details: error.response?.data
      });
    }
    
    throw new GroqError(
      'UNKNOWN_ERROR',
      `Failed to get response from Groq: ${error.message}`
    );
  }
}

export async function getAvailableModels(apiKey: string) {
  if (!apiKey) {
    throw new GroqError('API_KEY_MISSING', 'API key is required to fetch available models');
  }

  try {
    const response = await axios.get(`${GROQ_API_URL}/models`, {
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
    });

    return response.data.data;
  } catch (error: any) {
    if (axios.isAxiosError(error)) {
      console.error('Error fetching models:', {
        status: error.response?.status,
        message: error.message,
        details: error.response?.data
      });
      
      if (error.response?.status === 401) {
        throw new GroqError('INVALID_API_KEY', 'Invalid API key. Please check your credentials.');
      }
    }
    
    throw new GroqError('FETCH_MODELS_ERROR', 'Failed to fetch available models');
  }
}