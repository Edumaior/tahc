import { Persona } from '../types/chat';
import { DEFAULT_PERSONAS } from '../data/personas';

const STORAGE_KEY = 'custom-personas';

export class PersonaStorage {
  static getPersonas(): Persona[] {
    const storedPersonas = localStorage.getItem(STORAGE_KEY);
    return storedPersonas ? JSON.parse(storedPersonas) : DEFAULT_PERSONAS;
  }

  static savePersonas(personas: Persona[]): void {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(personas));
  }

  static resetToDefault(): void {
    localStorage.removeItem(STORAGE_KEY);
  }
}