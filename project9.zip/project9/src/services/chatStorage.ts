import axios from 'axios';
import { ChatSession } from '../types/chat';

const API_URL = 'http://localhost:3001/api';

function serializeDate(obj: any): any {
  if (obj instanceof Date) {
    return obj.toISOString();
  }
  if (Array.isArray(obj)) {
    return obj.map(serializeDate);
  }
  if (obj && typeof obj === 'object') {
    return Object.fromEntries(
      Object.entries(obj).map(([key, value]) => [key, serializeDate(value)])
    );
  }
  return obj;
}

function deserializeDate(obj: any): any {
  if (typeof obj === 'string' && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}.\d{3}Z$/.test(obj)) {
    return new Date(obj);
  }
  if (Array.isArray(obj)) {
    return obj.map(deserializeDate);
  }
  if (obj && typeof obj === 'object') {
    return Object.fromEntries(
      Object.entries(obj).map(([key, value]) => [key, deserializeDate(value)])
    );
  }
  return obj;
}

export class ChatStorage {
  static async saveChat(session: ChatSession): Promise<void> {
    try {
      const serializedSession = serializeDate(session);
      await axios.post(`${API_URL}/chats`, serializedSession);
    } catch (error) {
      console.error('Error saving chat:', error);
      throw new Error('Failed to save chat');
    }
  }

  static async loadChat(id: string): Promise<ChatSession | null> {
    try {
      const response = await axios.get(`${API_URL}/chats/${id}`);
      return deserializeDate(response.data);
    } catch (error) {
      console.error('Error loading chat:', error);
      return null;
    }
  }

  static async listChats(): Promise<ChatSession[]> {
    try {
      const response = await axios.get(`${API_URL}/chats`);
      return deserializeDate(response.data);
    } catch (error) {
      console.error('Error listing chats:', error);
      return [];
    }
  }

  static async deleteChat(id: string): Promise<void> {
    try {
      await axios.delete(`${API_URL}/chats/${id}`);
    } catch (error) {
      console.error('Error deleting chat:', error);
      throw new Error('Failed to delete chat');
    }
  }

  static async updateChatTitle(id: string, newTitle: string): Promise<void> {
    try {
      await axios.patch(`${API_URL}/chats/${id}/title`, { title: newTitle });
    } catch (error) {
      console.error('Error updating chat title:', error);
      throw new Error('Failed to update chat title');
    }
  }
}