import { ChatSettings, DEFAULT_SETTINGS } from '../types/chat';

const SETTINGS_KEY = 'groq-chat-settings';

export class SettingsStorage {
  static getSettings(): ChatSettings {
    try {
      const data = localStorage.getItem(SETTINGS_KEY);
      if (!data) return DEFAULT_SETTINGS;
      return JSON.parse(data);
    } catch (error) {
      console.error('Error reading settings:', error);
      return DEFAULT_SETTINGS;
    }
  }

  static saveSettings(settings: ChatSettings): void {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    } catch (error) {
      console.error('Error saving settings:', error);
      throw new Error('Failed to save settings');
    }
  }

  static updateSettings(updates: Partial<ChatSettings>): ChatSettings {
    const currentSettings = this.getSettings();
    const newSettings = { ...currentSettings, ...updates };
    this.saveSettings(newSettings);
    return newSettings;
  }

  static clearSettings(): void {
    localStorage.removeItem(SETTINGS_KEY);
  }
}