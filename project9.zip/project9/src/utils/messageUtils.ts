import { v4 as uuidv4 } from 'uuid';
import { Message } from '../types/chat';

export function createMessage(
  role: 'user' | 'assistant' | 'system',
  content: string
): Message {
  return {
    id: uuidv4(),
    content,
    role,
    timestamp: new Date(),
  };
}