import React from 'react';
import { Settings, Eye, EyeOff } from 'lucide-react';
import { ChatSettings as ChatSettingsType, AVAILABLE_MODELS } from '../types/chat';

interface ChatSettingsProps {
  settings: ChatSettingsType;
  onSettingsChange: (settings: ChatSettingsType) => void;
  isOpen: boolean;
  onToggle: () => void;
}

export function ChatSettings({ settings, onSettingsChange, isOpen, onToggle }: ChatSettingsProps) {
  const [showApiKey, setShowApiKey] = React.useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const newValue = type === 'number' ? parseFloat(value) : value;
    onSettingsChange({ ...settings, [name]: newValue });
  };

  return (
    <div className="relative">
      <button
        onClick={onToggle}
        className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
        title="Chat Settings"
      >
        <Settings className="w-5 h-5 text-gray-600" />
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg border p-4 z-20">
          <h3 className="font-semibold mb-4">Chat Settings</h3>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Groq API Key
              </label>
              <div className="relative">
                <input
                  type={showApiKey ? 'text' : 'password'}
                  name="apiKey"
                  value={settings.apiKey}
                  onChange={handleChange}
                  placeholder="Enter your Groq API key"
                  className="w-full px-3 py-2 border rounded-lg pr-10 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowApiKey(!showApiKey)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-gray-500 hover:text-gray-700"
                >
                  {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Model
              </label>
              <select
                name="model"
                value={settings.model}
                onChange={handleChange}
                className="w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
              >
                {AVAILABLE_MODELS.map((model) => (
                  <option key={model} value={model}>
                    {model}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Temperature ({settings.temperature})
              </label>
              <input
                type="range"
                name="temperature"
                min="0"
                max="1"
                step="0.1"
                value={settings.temperature}
                onChange={handleChange}
                className="w-full"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Top P ({settings.topP})
              </label>
              <input
                type="range"
                name="topP"
                min="0"
                max="1"
                step="0.1"
                value={settings.topP}
                onChange={handleChange}
                className="w-full"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Max Tokens
              </label>
              <input
                type="number"
                name="maxTokens"
                min="1"
                max="32768"
                value={settings.maxTokens}
                onChange={handleChange}
                className="w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Presence Penalty ({settings.presencePenalty})
              </label>
              <input
                type="range"
                name="presencePenalty"
                min="-2"
                max="2"
                step="0.1"
                value={settings.presencePenalty}
                onChange={handleChange}
                className="w-full"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Frequency Penalty ({settings.frequencyPenalty})
              </label>
              <input
                type="range"
                name="frequencyPenalty"
                min="-2"
                max="2"
                step="0.1"
                value={settings.frequencyPenalty}
                onChange={handleChange}
                className="w-full"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}