import React, { useRef, useEffect } from 'react';
import { Message } from '../types/chat';
import { ChatMessage } from './ChatMessage';
import { WelcomeMessage } from './WelcomeMessage';
import { ErrorMessage } from './ErrorMessage';
import { Loader } from 'lucide-react';

interface ChatWindowProps {
  messages: Message[];
  isLoading: boolean;
  error: string | null;
  onRegenerate?: () => void;
  onFeedback?: (type: 'positive' | 'negative') => void;
}

export function ChatWindow({ 
  messages, 
  isLoading, 
  error,
  onRegenerate,
  onFeedback 
}: ChatWindowProps) {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <main className="flex-1 overflow-y-auto p-6">
      <div className="max-w-3xl mx-auto space-y-6">
        {messages.length === 0 && !isLoading && !error && <WelcomeMessage />}
        
        {error && <ErrorMessage message={error} />}
        
        {messages.map((message, index) => (
          <ChatMessage 
            key={message.id} 
            message={message}
            onRegenerate={index === messages.length - 1 && message.role === 'assistant' ? onRegenerate : undefined}
            onFeedback={message.role === 'assistant' ? onFeedback : undefined}
          />
        ))}
        
        {isLoading && (
          <div className="flex items-center gap-2 text-gray-500 animate-pulse">
            <Loader className="w-5 h-5 animate-spin" />
            <div>Groq is thinking...</div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>
    </main>
  );
}