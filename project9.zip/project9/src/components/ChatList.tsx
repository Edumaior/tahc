import React, { useState } from 'react';
import { MessageSquare, Trash2, Edit2, Save, X } from 'lucide-react';
import { ChatSession } from '../types/chat';

interface ChatListProps {
  chats: ChatSession[];
  onSelectChat: (chat: ChatSession) => void;
  onDeleteChat: (chatId: string) => void;
  onUpdateChatTitle: (chatId: string, newTitle: string) => void;
  selectedChatId?: string;
}

export function ChatList({ 
  chats, 
  onSelectChat, 
  onDeleteChat, 
  onUpdateChatTitle,
  selectedChatId 
}: ChatListProps) {
  const [editingChatId, setEditingChatId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: 'numeric',
    }).format(date);
  };

  const handleEditStart = (chat: ChatSession) => {
    setEditingChatId(chat.id);
    setEditTitle(chat.title);
  };

  const handleSaveTitle = (chatId: string) => {
    onUpdateChatTitle(chatId, editTitle);
    setEditingChatId(null);
  };

  const handleCancelEdit = () => {
    setEditingChatId(null);
    setEditTitle('');
  };

  return (
    <div className="w-64 bg-gray-50 border-r overflow-y-auto">
      <div className="p-4">
        <h2 className="text-lg font-semibold mb-4">Chat History</h2>
        <div className="space-y-2">
          {chats.map((chat) => (
            <div
              key={chat.id}
              className={`flex items-center justify-between p-2 rounded-lg cursor-pointer hover:bg-gray-100 ${
                selectedChatId === chat.id ? 'bg-gray-100' : ''
              }`}
              onClick={() => !editingChatId && onSelectChat(chat)}
            >
              <div className="flex items-center gap-2 flex-1 min-w-0">
                <MessageSquare className="w-4 h-4 text-gray-500 flex-shrink-0" />
                {editingChatId === chat.id ? (
                  <div className="flex items-center gap-1 flex-1">
                    <input
                      type="text"
                      value={editTitle}
                      onChange={(e) => setEditTitle(e.target.value)}
                      className="flex-1 px-2 py-1 text-sm border rounded"
                      onClick={(e) => e.stopPropagation()}
                      autoFocus
                    />
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleSaveTitle(chat.id);
                      }}
                      className="p-1 hover:bg-gray-200 rounded"
                    >
                      <Save className="w-4 h-4 text-green-500" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleCancelEdit();
                      }}
                      className="p-1 hover:bg-gray-200 rounded"
                    >
                      <X className="w-4 h-4 text-red-500" />
                    </button>
                  </div>
                ) : (
                  <div className="truncate">
                    <div className="font-medium truncate">{chat.title}</div>
                    <div className="text-xs text-gray-500">
                      {formatDate(chat.updatedAt)}
                    </div>
                  </div>
                )}
              </div>
              {!editingChatId && (
                <div className="flex gap-1">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleEditStart(chat);
                    }}
                    className="p-1 hover:bg-gray-200 rounded"
                  >
                    <Edit2 className="w-4 h-4 text-gray-500" />
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteChat(chat.id);
                    }}
                    className="p-1 hover:bg-gray-200 rounded"
                  >
                    <Trash2 className="w-4 h-4 text-gray-500" />
                  </button>
                </div>
              )}
            </div>
          ))}
          {chats.length === 0 && (
            <div className="text-center text-gray-500 py-4">No saved chats</div>
          )}
        </div>
      </div>
    </div>
  );
}