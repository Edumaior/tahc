import React from 'react';
import { UserCircle, Bot } from 'lucide-react';
import { Message } from '../types/chat';
import { formatTimestamp } from '../utils/dateUtils';
import { MessageContent } from './MessageContent';
import { MessageActions } from './MessageActions';

interface ChatMessageProps {
  message: Message;
  onRegenerate?: () => void;
  onFeedback?: (type: 'positive' | 'negative') => void;
}

export function ChatMessage({ message, onRegenerate, onFeedback }: ChatMessageProps) {
  const isUser = message.role === 'user';

  return (
    <div className={`flex gap-3 ${isUser ? 'flex-row-reverse' : ''}`}>
      <div className="flex-shrink-0">
        {isUser ? (
          <UserCircle className="w-8 h-8 text-blue-500" />
        ) : (
          <Bot className="w-8 h-8 text-purple-500" />
        )}
      </div>
      <div
        className={`flex flex-col max-w-[80%] ${
          isUser ? 'items-end' : 'items-start'
        }`}
      >
        <div
          className={`rounded-lg px-4 py-2 ${
            isUser
              ? 'bg-blue-500 text-white'
              : 'bg-gray-100 text-gray-800'
          }`}
        >
          <MessageContent content={message.content} />
        </div>
        <span className="text-xs text-gray-500 mt-1">
          {formatTimestamp(message.timestamp)}
        </span>
        {!isUser && (
          <MessageActions
            onRegenerate={onRegenerate}
            onFeedback={onFeedback}
            showRegenerate={true}
          />
        )}
      </div>
    </div>
  );
}