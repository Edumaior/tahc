import React, { useState } from 'react';
import { Bot, Code, Lightbulb, Settings } from 'lucide-react';
import { Persona } from '../types/chat';
import { PersonaEditor } from './PersonaEditor';
import { PersonaStorage } from '../services/personaStorage';

interface PersonaSelectorProps {
  selectedPersonaId?: string;
  onSelectPersona: (persona: Persona) => void;
}

const IconMap = {
  Bot: Bot,
  Code: Code,
  Lightbulb: Lightbulb,
};

export function PersonaSelector({ selectedPersonaId, onSelectPersona }: PersonaSelectorProps) {
  const [personas, setPersonas] = useState<Persona[]>(PersonaStorage.getPersonas());
  const [editingPersona, setEditingPersona] = useState<Persona | null>(null);

  const handleSavePersona = (updatedPersona: Persona) => {
    const updatedPersonas = personas.map(p =>
      p.id === updatedPersona.id ? updatedPersona : p
    );
    setPersonas(updatedPersonas);
    PersonaStorage.savePersonas(updatedPersonas);
  };

  const handleResetPersonas = () => {
    PersonaStorage.resetToDefault();
    setPersonas(PersonaStorage.getPersonas());
  };

  return (
    <div className="space-y-4 p-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">Choose a Persona</h2>
        <button
          onClick={handleResetPersonas}
          className="text-sm text-gray-600 hover:text-gray-900"
        >
          Reset to Default
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {personas.map((persona) => {
          const Icon = IconMap[persona.icon as keyof typeof IconMap];
          const isSelected = selectedPersonaId === persona.id;
          
          return (
            <div
              key={persona.id}
              className={`relative flex flex-col items-center p-4 rounded-lg border transition-all ${
                isSelected
                  ? 'border-purple-500 bg-purple-50'
                  : 'border-gray-200 hover:border-purple-200 hover:bg-purple-50/50'
              }`}
            >
              <button
                onClick={() => setEditingPersona(persona)}
                className="absolute top-2 right-2 p-1 hover:bg-gray-200 rounded-full"
                title="Edit Persona"
              >
                <Settings className="w-4 h-4 text-gray-500" />
              </button>

              <button
                onClick={() => onSelectPersona(persona)}
                className="w-full h-full flex flex-col items-center"
              >
                <Icon className={`w-8 h-8 mb-2 ${
                  isSelected ? 'text-purple-500' : 'text-gray-600'
                }`} />
                <h3 className="font-semibold text-lg mb-1">{persona.name}</h3>
                <p className="text-sm text-gray-600 text-center">{persona.description}</p>
              </button>
            </div>
          );
        })}
      </div>

      {editingPersona && (
        <PersonaEditor
          persona={editingPersona}
          onSave={handleSavePersona}
          onClose={() => setEditingPersona(null)}
        />
      )}
    </div>
  );
}