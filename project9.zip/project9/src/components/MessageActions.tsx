import React from 'react';
import { RefreshCw, ThumbsUp, ThumbsDown } from 'lucide-react';

interface MessageActionsProps {
  onRegenerate?: () => void;
  onFeedback?: (type: 'positive' | 'negative') => void;
  showRegenerate?: boolean;
}

export function MessageActions({ 
  onRegenerate, 
  onFeedback,
  showRegenerate = false 
}: MessageActionsProps) {
  return (
    <div className="flex items-center gap-2 mt-2">
      {showRegenerate && (
        <button
          onClick={onRegenerate}
          className="flex items-center gap-1 px-2 py-1 text-sm text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded"
          title="Regenerate response"
        >
          <RefreshCw className="w-4 h-4" />
          Regenerate
        </button>
      )}
      {onFeedback && (
        <div className="flex items-center gap-1">
          <button
            onClick={() => onFeedback('positive')}
            className="p-1 hover:bg-gray-100 rounded"
            title="Good response"
          >
            <ThumbsUp className="w-4 h-4" />
          </button>
          <button
            onClick={() => onFeedback('negative')}
            className="p-1 hover:bg-gray-100 rounded"
            title="Bad response"
          >
            <ThumbsDown className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
}