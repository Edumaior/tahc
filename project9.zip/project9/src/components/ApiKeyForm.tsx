import React, { useState } from 'react';
import { Eye, EyeOff, Save } from 'lucide-react';

interface ApiKeyFormProps {
  apiKey: string;
  onSave: (apiKey: string) => void;
}

export function ApiKeyForm({ apiKey, onSave }: ApiKeyFormProps) {
  const [key, setKey] = useState(apiKey);
  const [showKey, setShowKey] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      await onSave(key);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Groq API Key
        </label>
        <div className="relative">
          <input
            type={showKey ? 'text' : 'password'}
            value={key}
            onChange={(e) => setKey(e.target.value)}
            placeholder="Enter your Groq API key"
            className="w-full px-3 py-2 border rounded-lg pr-24 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
            required
          />
          <div className="absolute right-2 top-1/2 -translate-y-1/2 flex gap-1">
            <button
              type="button"
              onClick={() => setShowKey(!showKey)}
              className="p-1 text-gray-500 hover:text-gray-700"
            >
              {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
            <button
              type="submit"
              disabled={isSaving || !key}
              className="flex items-center gap-1 px-2 py-1 bg-purple-500 text-white rounded-md hover:bg-purple-600 disabled:bg-gray-300"
            >
              <Save className="w-4 h-4" />
              Save
            </button>
          </div>
        </div>
      </div>
    </form>
  );
}