import React from 'react';
import { MessageSquare } from 'lucide-react';

export function WelcomeMessage() {
  return (
    <div className="flex flex-col items-center justify-center text-center p-8 space-y-4">
      <MessageSquare className="w-16 h-16 text-purple-500" />
      <h2 className="text-2xl font-semibold text-gray-800">Welcome to Groq Chat</h2>
      <p className="text-gray-600 max-w-md">
        Start a conversation with Groq! Powered by the Mixtral-8x7B model, get help with coding, writing, analysis, and more.
      </p>
    </div>
  );
}