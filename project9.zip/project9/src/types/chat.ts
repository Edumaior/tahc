export interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant' | 'system';
  timestamp: Date;
}

export interface ChatSession {
  id: string;
  title: string;
  createdAt: Date;
  updatedAt: Date;
  messages: Message[];
  settings: ChatSettings;
  selectedPersona?: string;
}

export interface ChatState {
  messages: Message[];
  isLoading: boolean;
  error: string | null;
}

export interface ChatSettings {
  apiKey: string;
  model: string;
  temperature: number;
  topP: number;
  maxTokens: number;
  presencePenalty: number;
  frequencyPenalty: number;
  stop: string[];
}

export interface Persona {
  id: string;
  name: string;
  description: string;
  systemPrompt: string;
  icon: string;
}

export const AVAILABLE_MODELS = [
  'mixtral-8x7b-32768',
  'llama3-70b-8192',
  'llama3-8b-8192',
  'gemma-7b-it',
  'llama3-groq-70b-8192-tool-use-preview',
  'llama3-groq-8b-8192-tool-use-preview',
  'llama-3.2-90b-vision-preview',
  'llama-3.2-11b-vision-preview',
  'llama-3.2-11b-text-preview',
  'llama-3.2-90b-text-preview',
  'llama-3.2-3b-preview',
  'llama-3.2-1b-preview',
  'llama-3.1-70b-versatile',
  'llama-3.1-8b-instant',
  'llama-guard-3-8b',
  'gemma2-9b-it'
] as const;

export const DEFAULT_SETTINGS: ChatSettings = {
  apiKey: '',
  model: 'mixtral-8x7b-32768',
  temperature: 0.7,
  topP: 1,
  maxTokens: 1024,
  presencePenalty: 0,
  frequencyPenalty: 0,
  stop: []
};