export class GroqError extends Error {
  constructor(
    public code: string,
    message: string
  ) {
    super(message);
    this.name = 'GroqError';
  }
}

export class StorageError extends Error {
  constructor(
    public code: string,
    message: string
  ) {
    super(message);
    this.name = 'StorageError';
  }
}

export type ErrorCode = 
  | 'API_KEY_MISSING'
  | 'INVALID_API_KEY'
  | 'NO_RESPONSE'
  | 'RATE_LIMIT'
  | 'SERVER_ERROR'
  | 'FETCH_MODELS_ERROR'
  | 'STORAGE_ERROR'
  | 'UNKNOWN_ERROR';