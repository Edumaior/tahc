import { useState, useCallback, useEffect } from 'react';
import { Message, ChatSettings, DEFAULT_SETTINGS, ChatSession, Persona } from '../types/chat';
import { sendMessageToGroq } from '../services/groqApi';
import { ChatStorage } from '../services/chatStorage';
import { PersonaStorage } from '../services/personaStorage';
import { GroqError } from '../types/errors';
import { v4 as uuidv4 } from 'uuid';
import { createMessage } from '../utils/messageUtils';

export function useChat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [settings, setSettings] = useState<ChatSettings>(DEFAULT_SETTINGS);
  const [currentChatId, setCurrentChatId] = useState<string | null>(null);
  const [savedChats, setSavedChats] = useState<ChatSession[]>([]);
  const [selectedPersona, setSelectedPersona] = useState<Persona | null>(null);

  const loadSavedChats = useCallback(async () => {
    try {
      const chats = await ChatStorage.listChats();
      setSavedChats(chats);
    } catch (error) {
      console.error('Error loading saved chats:', error);
      setError('Failed to load saved chats');
    }
  }, []);

  useEffect(() => {
    loadSavedChats();
  }, [loadSavedChats]);

  const saveCurrentChat = useCallback(async () => {
    if (messages.length === 0) return;

    try {
      const chatId = currentChatId || uuidv4();
      const title = messages[0].content.slice(0, 50) + (messages[0].content.length > 50 ? '...' : '');
      
      const session: ChatSession = {
        id: chatId,
        title,
        messages,
        settings,
        createdAt: new Date(),
        updatedAt: new Date(),
        selectedPersona: selectedPersona?.id
      };

      await ChatStorage.saveChat(session);
      setCurrentChatId(chatId);
      await loadSavedChats();
    } catch (error) {
      console.error('Error saving chat:', error);
      setError('Failed to save chat');
    }
  }, [messages, settings, currentChatId, loadSavedChats, selectedPersona]);

  const sendMessage = useCallback(async (content: string) => {
    if (!content.trim()) return;
    
    setError(null);
    const userMessage = createMessage('user', content);

    const messagesToSend = [...messages];
    
    if (selectedPersona && messages.length === 0) {
      messagesToSend.unshift(createMessage('system', selectedPersona.systemPrompt));
    }

    messagesToSend.push(userMessage);
    setMessages(messagesToSend);
    setIsLoading(true);

    try {
      const response = await sendMessageToGroq(messagesToSend, settings);
      const assistantMessage = createMessage('assistant', response);
      setMessages((prev) => [...prev, assistantMessage]);
      await saveCurrentChat();
    } catch (error) {
      if (error instanceof GroqError) {
        setError(error.message);
      } else {
        setError('An unexpected error occurred. Please try again.');
      }
      console.error('Error:', error);
    } finally {
      setIsLoading(false);
    }
  }, [messages, settings, saveCurrentChat, selectedPersona]);

  const regenerateLastMessage = useCallback(async () => {
    if (messages.length < 2) return;

    const lastUserMessage = [...messages].reverse().find(m => m.role === 'user');
    if (!lastUserMessage) return;

    const newMessages = messages.slice(0, -1);
    setMessages(newMessages);
    await sendMessage(lastUserMessage.content);
  }, [messages, sendMessage]);

  const handleFeedback = useCallback((type: 'positive' | 'negative') => {
    console.log('Message feedback:', type);
  }, []);

  const updateSettings = useCallback((newSettings: ChatSettings) => {
    setSettings(newSettings);
  }, []);

  const clearChat = useCallback(() => {
    setMessages([]);
    setError(null);
    setCurrentChatId(null);
    setSelectedPersona(null);
  }, []);

  const selectPersona = useCallback((persona: Persona) => {
    setSelectedPersona(persona);
    setMessages([]);
    setCurrentChatId(null);
  }, []);

  const loadChat = useCallback(async (chatId: string) => {
    try {
      const session = await ChatStorage.loadChat(chatId);
      if (session) {
        setMessages(session.messages);
        setSettings(session.settings);
        setCurrentChatId(session.id);
        if (session.selectedPersona) {
          const personas = PersonaStorage.getPersonas();
          const persona = personas.find(p => p.id === session.selectedPersona);
          setSelectedPersona(persona || null);
        }
        setError(null);
      }
    } catch (error) {
      console.error('Error loading chat:', error);
      setError('Failed to load chat');
    }
  }, []);

  const deleteChat = useCallback(async (chatId: string) => {
    try {
      await ChatStorage.deleteChat(chatId);
      if (chatId === currentChatId) {
        clearChat();
      }
      await loadSavedChats();
    } catch (error) {
      console.error('Error deleting chat:', error);
      setError('Failed to delete chat');
    }
  }, [currentChatId, clearChat, loadSavedChats]);

  return {
    messages,
    isLoading,
    error,
    settings,
    savedChats,
    currentChatId,
    selectedPersona,
    sendMessage,
    regenerateLastMessage,
    handleFeedback,
    updateSettings,
    clearChat,
    startNewChat: clearChat,
    loadChat,
    deleteChat,
    selectPersona,
  };
}